URL: https://www.gutenberg.org/ebooks/6318
Title: L'Avare
Author: Molière, 1622-1673
Release: 2004/08/01
